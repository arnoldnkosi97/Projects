﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
  public  class ComplaintDa
    {
        private static SqlConnection db = new SqlConnection(ConfigurationManager.ConnectionStrings["default"].ConnectionString);

        //public static DataTable SelectComplaint(SqlCommand cmd)
        //{
        //    using (SqlDataAdapter sda = new SqlDataAdapter("sp_selectComplaint", db))
        //    {
        //        DataTable dt = new DataTable();
        //        sda.Fill(dt);
        //        return dt;
        //    }
        //}

        public static void InsertComplaint(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_insertingComplaint";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }

        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        public static void DeleteComplaint(SqlCommand cmd,string query)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = QueryBuilder.deleteComplaint+query;
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            db.Close();
        }
        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        public static void UpdateComplaint(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_UpdateComplaint";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }
    }
}
