﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
   public class MaintenanceDa
    {
        //

        private static SqlConnection db = new SqlConnection(ConfigurationManager.ConnectionStrings["default"].ConnectionString);

        public static DataTable SelectContact()
        {
            using (SqlDataAdapter sda = new SqlDataAdapter("", db))
            {
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
        }

        public static void InsertMaintenance(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_insertMaintenance";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }

        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        public static void DeleteMaintenance(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }
        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        public static void UpdateMaintenance(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_UpdateMaintenance";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }
    }
}
