﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace SafeHomeSystem
{
   public class LoginDa
    {
        private static SqlConnection db = new SqlConnection(ConfigurationManager.ConnectionStrings["default"].ConnectionString);

        public static DataTable SelectLogin()
        {
            using (SqlDataAdapter sda = new SqlDataAdapter("sp_", db))
            {
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
        }

        public static void InsertLogin(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }

        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        public static void DeleteLogin(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }
        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        //public static void UpdateAddress(SqlCommand cmd)
        //{
        //    db.Open();
        //    cmd.Connection = db;
        //    cmd.CommandText = "sp_";
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.ExecuteNonQuery();
        //    db.Close();
        //}
    }
}
