﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
   public class StaffDa
    {
        private static SqlConnection db = new SqlConnection(ConfigurationManager.ConnectionStrings["default"].ConnectionString);

        public static DataTable SelectStaff()
        {
            using (SqlDataAdapter sda = new SqlDataAdapter("sp_selectStaff", db))
            {
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
        }

        public static void InsertStaff(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_insertStaff";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }

        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        public static void DeleteStaff(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "[dbo].[sp_deleteStaff]";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }
        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        public static void UpdateStaff(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_updateStaff";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }
    }
}
