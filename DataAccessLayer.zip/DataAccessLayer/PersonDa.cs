﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using SafeHomeSystem;
using System.Data;

namespace SafeHomeSystem
{
    public class PersonDa
    {

        private string connectionString;
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataAdapter adapter;
        private DataTable dataTable;
    

        private static SqlConnection db = new SqlConnection(ConfigurationManager.ConnectionStrings["default"].ConnectionString);


        public static DataTable SelectPeople()
        {
            using (SqlDataAdapter sda = new SqlDataAdapter("sp_SelectPeople", db))
            {
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;

                
            }
        }






        /// <summary>
        /// ////////////////////////////////
        /// </summary>
        /// <param name="cmd"></param>
        public static void InsertPerson(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_insertPerson";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }

        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        public static void DeletePerson(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_deletePeople";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }
        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        public static void UpdatePerson(SqlCommand cmd)
        {
            db.Open();
            cmd.Connection = db;
            cmd.CommandText = "sp_updatePerson";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            db.Close();
        }
    }
}
