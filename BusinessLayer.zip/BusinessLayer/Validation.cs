﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
  public  class Validationss
     {
   
        public delegate void MyEventHandler();

        public event MyEventHandler CheckEmpty;

        private string  id;

        public string ID
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
                if (id ==null)
                {
                    WarningEmpty();
                }
            }
        }
        public void WarningEmpty()
        {
            Console.WriteLine("ID cannot be empty");
                
        }
    }
}
