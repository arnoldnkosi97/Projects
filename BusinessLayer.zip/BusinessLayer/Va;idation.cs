﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class Validations
    {

        public string ifEmpty(string input)
        {
            string inputValue = input;
            if (inputValue == null)
            {
                return inputValue = "Empty";
            }

            else
            {
                return inputValue = "NotEmpty";
            }
        }

        public string checkString(string input)
        {
            string inputValue = input;
            //   string stringPattern;

            return inputValue;
        }

        public int checkInt(int input)
        {
            int inputValue = input;
            //  string stringPattern;

            return inputValue;
        }

    }
}
